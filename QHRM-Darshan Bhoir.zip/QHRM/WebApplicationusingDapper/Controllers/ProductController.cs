﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplicationusingDapper.Models;

namespace WebApplicationusingDapper.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ProductRepository productRepository;

        public ProductController()
        {
            productRepository = new ProductRepository();

        }

        //Get all
        [HttpGet]
        [Route("Get")]
        public IEnumerable<Product> GetProducts()
        {
            return productRepository.GetAll();
        }

        //Insert
        [HttpPost]
        public void Post([FromBody] Product product)
        {
            if (ModelState.IsValid)
            {
                productRepository.Add(product);
            }
        }

        //Update
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Product product)
        {
            product.Id = id;
            if (ModelState.IsValid)
            {
                productRepository.Update(product);
            }
        }

        //Delete
        [HttpDelete]
        public void Delete(int id)
        {
            productRepository.Delete(id);
        }

    }
}
