﻿using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace WebApplicationusingDapper.Models
{
    public class ProductRepository
    {
        private string constr;
        public ProductRepository()
        {
            //Connection string
            constr = @"Data Source=VOSTRO\SQLEXPRESS;Initial Catalog=QHRMApp;Integrated Security=true";
        }

        public IDbConnection Connection
        {
            get 
            {
                return new SqlConnection(constr); 
            }
        }

        //Add Product
        public void Add(Product product)
        {
            using(IDbConnection conn = Connection)
            {
                conn.Open();
                string sql = @"INSERT INTO Product (Name, Price) VALUES (@name, @price)";
                conn.Execute(sql, product);
                conn.Close();
            }
        }

        //get All Product
        public IEnumerable<Product> GetAll()
        {
            using(IDbConnection conn = Connection)
            {
                conn.Open();
                string sql = @"SELECT * FROM Product";
                return conn.Query<Product>(sql);
                conn.Close();
            }
        }

        //Upadte Product
        public void Update(Product product)
        {
            using(IDbConnection conn = Connection)
            {
                conn.Open();
                string sql = @"UPDATE Product SET Name=@name, Price=@price WHERE Id=@id";
                conn.Query(sql, product);
                conn.Close();
            }
        }

        //Delete Product
        public void Delete(int id)
        {
            using(IDbConnection conn = Connection)
            {
                conn.Open();
                string sql = @"DELETE FROM Product WHERE Id=@id";
                conn.Query(sql, new {Id=id});
                conn.Close();
            }
        }
    }
}
