// $(document).ready(
//     function(){
//         $('#addproduct').click(()=>{
//             const name=$("#pname").val();
//             const price=$("#pprice").val();

//             $.post(`https://localhost:7060/api/Product`,{
//                 name:name,
//                 price:price,

//             })
//             .done(function(data) {
//                 alert("New Product added");
//                 window.location.href = "index.html";
//               })
//               .fail(function() {
//                 alert("Error occurred while adding the product");
//               });

//         })
//     }

// )


$(document).ready(function() {
    $('#addproduct').click(function(event) {
      event.preventDefault();
  
      const name = $("#pname").val();
      const price = $("#pprice").val();
      console.log(name);
      console.log(price);
  
      $.ajax({
        url: `https://localhost:7060/api/Product`,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
          "name": name,
          "price": price
        }),
        datatype: 'json',
        success: function (data) {
            console.log(data)
          alert("New Product added");
          window.location.href = "index.html";
        },
        error: function() {
            console.log(error)
          alert("Error occurred while adding the product");
        }
      });
    });
  });
  