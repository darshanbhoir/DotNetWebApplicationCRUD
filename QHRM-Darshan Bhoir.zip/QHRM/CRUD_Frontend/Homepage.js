
$(document).ready(function () {
    


    //Get All Product
    $.ajax({
        url: "https://localhost:7060/api/Product/Get",
        type: "GET",
        dataType: "json",
        success: function (data) {
            console.log(data)
            
            const tbody = $("#pdata");
            var count =1;
            $.each(data, function (index, obj) {
                console.log("row initialise")
                var row = $("<tr></tr>");

                const Idcell = $("<td></td>").text(obj.id);
                const Namecell = $("<td></td>").text(obj.name);
                const Pricecell = $("<td></td>").text(obj.price);
                const updateCell = $("<button class='updateProduct'></button>").text("Update");
                const deleteCell = $("<button class='deleteProduct'></button>").text("Delete");

                row.append(Idcell, Namecell, Pricecell,updateCell,deleteCell    );
                tbody.append(row);
                count++;
            });

            //Update Product
            $(".updateProduct").click(function (){
                var row =$(this).closest('tr');
                var id = row.find('td:eq(0)').text();
                var name = row.find('td:eq(1)').text();
                var price = row.find('td:eq(2)').text();
                $("#pid").val(id);
                $("#pname").val(name);
                $("#pprice").val(price);
                
            });
                $("#updateForm").submit(function (event){
                    event.preventDefault();
                    var id = $("#pid").val();
                    var name = $("#pname").val();
                    var price = $("#pprice").val();

                    $.ajax({
                        url: `https://localhost:7060/api/Product/${id}`,
                        method:'PUT',
                        contentType: "application/json",
                        data:JSON.stringify({
                            name:name,
                            price:price
                        }),
                        datatype: 'json',
                        success: function (data) {
                            console.log(data);
                            alert("Product updated successfully.");
                            window.location.href="Index.html";
                        },
                        error: function (error) {
                            console.log(error);
                            alert("Product update failed.");
                        }
                    })
                })


            //Delete Product
            $(".deleteProduct").click(function (event){
                event.preventDefault();
                var row = $(this).closest('tr');
                var id = row.find('td:eq(0)').text();

                $.ajax({
                    url: `https://localhost:7060/api/Product?id=${id}`,
                    method: 'DELETE',
                    success: function (data) {
                        console.log(data);
                        alert("are you sure to delete product");
                        row.remove();
                        window.location.href = "Index.html";
                    },
                    error: function (error) {
                        console.log(error);
                        alert("Product delete failed.");
                    }
                })
            })

        },
        error: function (error) {
            console.log(error);
        }
    });
});
